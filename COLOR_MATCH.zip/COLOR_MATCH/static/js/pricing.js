// Initialize 3D tilt
VanillaTilt.init(document.querySelectorAll(".pricing-card"), {
    max: 15,
    speed: 400,
    glare: true
});

// Particles.js config
particlesJS("particles-js", {
    particles: {
        number: { value: 80, density: { enable: true, value_area: 800 } },
        color: { value: "#4361ee" },
        shape: { type: "circle" },
        opacity: { value: 0.3, random: true },
        size: { value: 3, random: true },
        line_linked: { enable: true, distance: 150, color: "#4895ef", opacity: 0.2, width: 1 },
        move: { enable: true, speed: 2, direction: "none", random: true }
    }
});